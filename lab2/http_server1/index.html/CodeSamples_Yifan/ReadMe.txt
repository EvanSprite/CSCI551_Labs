These are some code samples of Yifan Wu.

"AtoPartOfSpeechTagging" is a course design of automatically tagging text using some marks, in course Natural Language Processing.

"bit-minic" is a graduation design of a C language compiler framework including a small compiler using a subset of C grammers.

"JavaHomework" is a course design of keyword searching in different files and documents, in course Java.

"MMSeg" is a course design of automatic segmenting for Chinese, in course Natural Language Processing.

"WudaoChess" is a course design of a game named Five Chess, using alpha-beta pruning, neural network and genetic algorithms, in course Artificial Intelligence.

"K-means" is part of code of a cluster algorithm used in the project Design of Real-Time Dynamic Recognition System for Merging Multi-Vision Object Complex Event.

"OSProgrammingTest" is a course design of imitating some functions of operation system, in course Operating System.

"Socket_Client" and "Socket_Server" is course designs of imitating socket communication through network, in course Network.

"Message" is a course design of message transceiving system.